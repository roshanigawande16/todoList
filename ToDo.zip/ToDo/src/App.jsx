import './App.css'
import ToDoWrapper from './Components/TodoWrapper'
function App() {
  return (
    <>
    <div className='TodoWrapper'>
   <ToDoWrapper/>
    </div>
    </>
  )
}

export default App
